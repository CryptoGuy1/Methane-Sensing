/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * This is the main entrypoint for the sample REST server, which is responsible
 * for connecting to the Fabric network and setting up a job queue for
 * processing submit transactions
 */

import * as config from './config';
import {
  //createGateway,
  enrollAdmin,
  //registerAndEnrollUser,
  createConnectionProfile,
  createWallet,
  //getContracts,
  //getNetwork,
} from './fabric';
import {
  initJobQueue,
  initJobQueueScheduler,
  initJobQueueWorker,
} from './jobs';
import { logger } from './logger';
import { createServer } from './server';
import { isMaxmemoryPolicyNoeviction } from './redis';
import { Queue, QueueScheduler, Worker } from 'bullmq';
import FabricCAServices from 'fabric-ca-client';
import * as path from 'path';
import * as fs from 'fs';

import { Gateway } from 'fabric-network';

let jobQueue: Queue | undefined;
let jobQueueWorker: Worker | undefined;
let jobQueueScheduler: QueueScheduler | undefined;

async function main() {
  logger.info('Checking Redis config');
  if (!(await isMaxmemoryPolicyNoeviction())) {
    throw new Error(
      'Invalid redis configuration: redis instance must have the setting maxmemory-policy=noeviction'
    );
  }

  logger.info('Creating REST server');
  const app = await createServer();

  logger.info('Connecting to Fabric network with org1 mspid');
  const wallet = await createWallet();
  logger.info('Filesystem wallet', wallet);
  const caOrg1 = new FabricCAServices(config.caOrg1Url);
  logger.info('B');
  const caOrg2 = new FabricCAServices(config.caOrg2Url);
  logger.info('C');

  await enrollAdmin(
    caOrg1,
    wallet,
    config.mspIdOrg1,
    config.adminIdOrg1,
    config.adminSecretOrg1
  );
  logger.info('D');
  await enrollAdmin(
    caOrg2,
    wallet,
    config.mspIdOrg2,
    config.adminIdOrg2,
    config.adminSecretOrg2
  );
  logger.info('Checking wallet contents');

  logger.info('G');
  const connectionProfileOrg1 = createConnectionProfile(
    'Org1',
    config.caOrg1Url,
    config.peerOrg1Url
  );
  logger.info('H');
  logger.info('Created connection profile for Org1:');
  logger.info(JSON.stringify(connectionProfileOrg1, null, 2));
  const connectionProfileOrg2 = createConnectionProfile(
    'Org2',
    config.caOrg2Url,
    config.peerOrg2Url
  );
  logger.info('Created connection profile for Org2:');
  logger.info(JSON.stringify(connectionProfileOrg2, null, 2));
  /*const gatewayOrg1 = await createGateway(
    connectionProfileOrg1,
    config.adminIdOrg1,
    wallet
  );*/

  const ccpPath = path.resolve(
    __dirname,
    '..',
    '..',
    '..',
    'test-network',
    'organizations',
    'peerOrganizations',
    'org1.example.com',
    'connection-org1.json'
  );
  const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

  const gatewayOrg1 = new Gateway();
  const adminIdentity1 = await wallet.get(config.adminIdOrg1);
  logger.info('Admin identity 1:');
  logger.info(JSON.stringify(adminIdentity1));
  logger.info(JSON.stringify(wallet));
  if (!adminIdentity1) {
    throw new Error(`Admin identity ${config.adminIdOrg1} not found in wallet`);
  }
  try {
    // await gatewayOrg1.connect(connectionProfileOrg1, {
    //   wallet,
    //   identity: config.adminIdOrg1,
    //   discovery: { enabled: true, asLocalhost: true },
    // });
    await gatewayOrg1.connect(ccp, {
      wallet,
      identity: config.adminIdOrg1,
      discovery: { enabled: true, asLocalhost: true },
    });
  } catch (error) {
    logger.error('Failed to connect to Org1 gateway', error);
    throw error;
  }

  const networkOrg1 = await gatewayOrg1.getNetwork('mychannel');
  if (!networkOrg1) {
    throw new Error('Failed to get network');
  }
  logger.info('Network retrieved successfully');
  const contractOrg1 = networkOrg1.getContract('basic');
  if (!contractOrg1) {
    throw new Error('Failed to get contract');
  }
  logger.info('Contract retrieved successfully');
  logger.info('Org1 network');
  //logger.info(networkOrg1);
  logger.info('Org1 contract');
  //logger.info(contractOrg1);

  //const networkOrg1 = await getNetwork(gatewayOrg1);
  logger.info('K');
  //const contractsOrg1 = await getContracts(networkOrg1);
  logger.info('L');

  //app.locals[config.mspIdOrg1] = contractsOrg1;
  app.locals[config.mspIdOrg1] = contractOrg1;

  logger.info('Connecting to Fabric network with org2 mspid');
  //   const gatewayOrg2 = await createGateway(
  //     connectionProfileOrg2,
  //     config.adminIdOrg2,
  //     wallet
  //   );

  //   const networkOrg2 = await getNetwork(gatewayOrg2);
  //   const contractsOrg2 = await getContracts(networkOrg2);

  const ccpPathOrg2 = path.resolve(
    __dirname,
    '..',
    '..',
    '..',
    'test-network',
    'organizations',
    'peerOrganizations',
    'org2.example.com',
    'connection-org2.json'
  );
  const ccpOrg2 = JSON.parse(fs.readFileSync(ccpPathOrg2, 'utf8'));

  const gatewayOrg2 = new Gateway();
  const adminIdentity2 = await wallet.get(config.adminIdOrg2);
  logger.info('Admin identity 2', adminIdentity2);
  if (!adminIdentity2) {
    throw new Error(`Admin identity ${config.adminIdOrg2} not found in wallet`);
  }
  try {
    // await gatewayOrg2.connect(connectionProfileOrg2, {
    //   wallet,
    //   identity: config.adminIdOrg2,
    //   discovery: { enabled: true, asLocalhost: true },
    // });
    await gatewayOrg2.connect(ccpOrg2, {
      wallet,
      identity: config.adminIdOrg2,
      discovery: { enabled: true, asLocalhost: true },
    });
  } catch (error) {
    logger.error('Failed to connect to Org2 gateway', error);
    throw error;
  }

  const networkOrg2 = await gatewayOrg2.getNetwork('mychannel');
  const contractOrg2 = networkOrg2.getContract('basic');

  app.locals[config.mspIdOrg2] = contractOrg2;

  logger.info('Initialising submit job queue');
  jobQueue = initJobQueue();
  jobQueueWorker = initJobQueueWorker(app);
  if (config.submitJobQueueScheduler === true) {
    logger.info('Initialising submit job queue scheduler');
    jobQueueScheduler = initJobQueueScheduler();
  }
  app.locals.jobq = jobQueue;

  logger.info('Starting REST server');
  app.listen(config.port, () => {
    logger.info('REST server started on port: %d', config.port);
  });
}

main().catch(async (err) => {
  logger.error({ err }, 'Unxepected error');

  if (jobQueueScheduler != undefined) {
    logger.debug('Closing job queue scheduler');
    await jobQueueScheduler.close();
  }

  if (jobQueueWorker != undefined) {
    logger.debug('Closing job queue worker');
    await jobQueueWorker.close();
  }

  if (jobQueue != undefined) {
    logger.debug('Closing job queue');
    await jobQueue.close();
  }
});
