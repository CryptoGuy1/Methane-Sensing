const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');
const { Board, Led } = require('johnny-five');

// Hyperledger Fabric network setup
const ccpPath = path.resolve(__dirname, '..', '..', '..', 'fabric-samples', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
const walletPath = path.join(process.cwd(), 'wallet');

async function main() {
    try {
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('admin');
        if (!identity) {
            console.log('An identity for the user "appUser3" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });

        const network = await gateway.getNetwork('mychannel');
        const contract = network.getContract('basic');

        // Initialize the Johnny-Five board
        const board = new Board();
        let led;

        board.on('ready', () => {
            led = new Led(13);
            console.log('Board is ready');
        });

        const listener = async (event) => {
            console.log(event);
            if (event.eventName === 'HighMethaneLevel') {
                const eventPayload = JSON.parse(event.payload.toString());
                console.log(`Event received: ${event.eventName} with payload: ${event.payload.toString()}`);

                if (led && eventPayload.Methanelevel > 3000) {
                    led.on();
                    console.log('LED is ON due to high methane level');
                    setTimeout(() => {
                        led.off();
                        console.log('LED is OFF');
                    }, 5000); // Turn off after 5 seconds
                }
            }
        };

        await contract.addContractListener(listener);

        console.log('Listening for contract events...');

        process.stdin.resume();
    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        process.exit(1);
    }
}

main();