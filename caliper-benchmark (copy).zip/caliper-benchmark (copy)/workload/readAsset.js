'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class MyWorkload extends WorkloadModuleBase {
    constructor() {
        super();

        this.timestamps = []; // Array to store timestamps
    }

    async initializeWorkloadModule(
        workerIndex,
        totalWorkers,
        roundIndex,
        roundArguments,
        sutAdapter,
        sutContext
    ) {
        await super.initializeWorkloadModule(
            workerIndex,
            totalWorkers,
            roundIndex,
            roundArguments,
            sutAdapter,
            sutContext
        );

        const epochTime = Math.floor(new Date().getTime() / 1000).toString(); // Get epoch timestamp in string format



        for (let i = 0; i < this.roundArguments.assets; i++) {
            const assetID = `${this.workerIndex}_${i}`;

            const myTimestamp = `${workerIndex}${epochTime}`;

            console.log(`Worker ${this.workerIndex}: Creating asset ${assetID}`);

            this.timestamps.push(myTimestamp); // Store timestamp for each asset

            const request = {
                contractId: this.roundArguments.contractId,

                contractFunction: 'CreateAsset',

                invokerIdentity: 'User1',

                contractArguments: [myTimestamp, '0', '0', '0'], // Use epochTime instead of fixed date

                readOnly: false,
            };

            await this.sutAdapter.sendRequests(request);
        }
    }

    async submitTransaction() {
        const randomId = Math.floor(Math.random() * this.roundArguments.assets);
        const timestamp = this.timestamps[randomId]; // Get timestamp for the chosen asset
      
        const myArgs = {
          contractId: this.roundArguments.contractId,
          contractFunction: 'ReadAsset',
          invokerIdentity: 'User1',
          contractArguments: [`${timestamp}`], // Use timestamp from array
          readOnly: true,
        };
      
        await this.sutAdapter.sendRequests(myArgs);
      }
      

    async cleanupWorkloadModule() {
        for (let i = 0; i < this.timestamps.length; i++) {
            const timestamp = this.timestamps[i]; // Get timestamp for the asset

            const request = {
                contractId: this.roundArguments.contractId,

                contractFunction: 'DeleteAsset',

                invokerIdentity: 'User1',

                contractArguments: [`${timestamp}`], // Use timestamp from array

                readOnly: false,
            };

            await this.sutAdapter.sendRequests(request);
        }
    }
}

function createWorkloadModule() {
    return new MyWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;