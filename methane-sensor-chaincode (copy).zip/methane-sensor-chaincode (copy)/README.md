# data-chaincode
Hyperledger Fabric chaincode (smart contract) for data storage
